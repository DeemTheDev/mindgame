<?php
if ( $field_type==='paid-service-label' ):
	$look_for_subs = 'paid-service';
	?>
	<div class="field field-paid-service">
		<label class="field-label"><?php echo htmlentities($value, ENT_QUOTES | ENT_IGNORE, "UTF-8"); ?><?php if ($is_required): ?><i class="required-asterisk fa fa-asterisk"></i><?php endif; ?></label>
		<input type="hidden" name="<?php echo $name; ?>" />
		<select<?php if ($is_required): echo ' required="required"'; endif; ?> name="<?php echo $name; ?>">
			<option value=""><?php _e('Select a Product', BOOKED_WC_LANGUAGE_PREFIX); ?></option>
<?php
endif;

return $look_for_subs;